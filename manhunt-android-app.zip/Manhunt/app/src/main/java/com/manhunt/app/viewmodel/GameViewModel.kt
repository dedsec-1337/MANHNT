package com.manhunt.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.manhunt.app.ManhuntApp
import com.manhunt.app.data.Constants
import com.manhunt.app.data.local.MatchHistoryEntity
import com.manhunt.app.data.local.PlayerProfileEntity
import com.manhunt.app.data.model.*
import com.manhunt.app.network.FirebaseSyncService
import com.manhunt.app.sensor.CompassSensorManager
import com.manhunt.app.service.ManhuntLocationService
import com.manhunt.app.util.GeoUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

import com.manhunt.app.util.BatteryOptimizationHelper
import com.manhunt.app.util.GeofenceManager
import com.manhunt.app.util.GeofenceStatus

data class GameUiState(
    val myPlayer: Player = Player(id = UUID.randomUUID().toString(), name = "Runner", avatarEmoji = "🏃"),
    val session: GameSession? = null,
    val players: List<Player> = emptyList(),
    val isOrganizer: Boolean = false,
    val headingDegrees: Float = 0f,
    val nearestSeekerDistance: Double = -1.0,
    val nearestSeekerBearing: Float = 0f,
    val nearbyCatchableHider: Player? = null,
    val isOutOfZone: Boolean = false,
    val geofenceStatus: GeofenceStatus = GeofenceStatus.INSIDE,
    val geofenceGraceSeconds: Int = 30,
    val geofenceMessage: String? = null,
    val isDarkMode: Boolean = false,
    val isBatteryOptimizationExempt: Boolean = false,
    val toastMessage: String? = null,
    val networkStatus: NetworkSyncStatus = NetworkSyncStatus.ONLINE,
    val isJoiningRoom: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val db = (application as ManhuntApp).database
    private val firebaseSync = FirebaseSyncService.instance
    private val compass = CompassSensorManager(application)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var countdownTimerJob: Job? = null
    private var lastHandledCatchAttemptTimestamp: Long = 0L

    init {
        loadUserProfile()
        observeSensorsAndLocation()
        observeCloudSync()
    }

    private fun loadUserProfile() {
        viewModelScope.launch {
            val profile = db.playerProfileDao().getProfile()
            if (profile != null) {
                _uiState.update {
                    it.copy(
                        myPlayer = it.myPlayer.copy(
                            id = profile.id,
                            name = profile.displayName,
                            avatarEmoji = profile.avatarEmoji
                        )
                    )
                }
            } else {
                val newProfile = PlayerProfileEntity(
                    id = _uiState.value.myPlayer.id,
                    displayName = "Agent ${RandomCode.generateCode(3)}",
                    avatarEmoji = "🏃"
                )
                db.playerProfileDao().upsertProfile(newProfile)
                _uiState.update {
                    it.copy(
                        myPlayer = it.myPlayer.copy(
                            id = newProfile.id,
                            name = newProfile.displayName,
                            avatarEmoji = newProfile.avatarEmoji
                        )
                    )
                }
            }
        }
    }

    fun updateProfile(name: String, emoji: String) {
        viewModelScope.launch {
            val updated = _uiState.value.myPlayer.copy(name = name, avatarEmoji = emoji)
            db.playerProfileDao().upsertProfile(
                PlayerProfileEntity(updated.id, updated.name, updated.avatarEmoji)
            )
            _uiState.update { it.copy(myPlayer = updated) }
        }
    }

    private fun observeSensorsAndLocation() {
        compass.startListening()
        viewModelScope.launch {
            compass.azimuthFlow.collect { heading ->
                _uiState.update { it.copy(headingDegrees = heading) }
            }
        }

        viewModelScope.launch {
            ManhuntLocationService.locationUpdates.collect { loc ->
                handleMyLocationUpdate(loc.latitude, loc.longitude)
            }
        }
    }

    private fun observeCloudSync() {
        // Observe connection/sync status
        viewModelScope.launch {
            firebaseSync.syncStatus.collect { status ->
                _uiState.update { it.copy(networkStatus = status) }
            }
        }

        // Observe cloud room updates
        viewModelScope.launch {
            firebaseSync.roomState.collect { roomModel ->
                if (roomModel != null) {
                    processIncomingRoomState(roomModel)
                }
            }
        }
    }

    /**
     * Organizer creates room on Firebase Realtime Database
     */
    fun createRoom(
        roomName: String,
        durationMinutes: Int,
        zoneRadiusMeters: Double,
        hiderRatio: Int,
        centerLat: Double = 40.785091,
        centerLng: Double = -73.968285
    ) {
        val joinCode = RandomCode.generateCode(6)
        val hostPlayer = _uiState.value.myPlayer.copy(
            role = Role.SEEKER,
            latitude = centerLat,
            longitude = centerLng
        )

        val newSession = GameSession(
            roomId = UUID.randomUUID().toString(),
            roomName = roomName,
            joinCode = joinCode,
            hostPlayerId = hostPlayer.id,
            status = GameStatus.LOBBY,
            zoneCenterLat = centerLat,
            zoneCenterLng = centerLng,
            zoneRadiusMeters = zoneRadiusMeters,
            durationMinutes = durationMinutes,
            remainingSeconds = durationMinutes * 60
        )

        val roomNetworkModel = RoomNetworkModel(
            session = newSession,
            players = mapOf(hostPlayer.id to hostPlayer)
        )

        viewModelScope.launch {
            val success = firebaseSync.createRoom(roomNetworkModel)
            if (success) {
                _uiState.update {
                    it.copy(
                        session = newSession,
                        myPlayer = hostPlayer,
                        players = listOf(hostPlayer),
                        isOrganizer = true,
                        toastMessage = "Room created! Share code: $joinCode"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(toastMessage = "Failed to create room. Check cellular data connection.")
                }
            }
        }
    }

    /**
     * Player joins room by fetching /rooms/{joinCode}.json from Firebase REST
     */
    fun joinRoom(code: String, onComplete: (Boolean) -> Unit = {}) {
        val upperCode = code.trim().uppercase()
        if (upperCode.length < 4) return

        _uiState.update { it.copy(isJoiningRoom = true) }

        viewModelScope.launch {
            val roomData = firebaseSync.fetchRoomData(upperCode)
            if (roomData != null && roomData.session.joinCode.isNotEmpty()) {
                val catchCode = if (_uiState.value.myPlayer.role == Role.HIDER) {
                    RandomCode.generateNumericCode(4)
                } else ""
                val playerToJoin = _uiState.value.myPlayer.copy(catchCode = catchCode)

                val joinSuccess = firebaseSync.joinPlayer(upperCode, playerToJoin)
                if (joinSuccess) {
                    _uiState.update {
                        it.copy(
                            session = roomData.session,
                            players = roomData.players.values.toList(),
                            myPlayer = playerToJoin,
                            isOrganizer = roomData.session.hostPlayerId == playerToJoin.id,
                            isJoiningRoom = false,
                            toastMessage = "Joined ${roomData.session.roomName}!"
                        )
                    }
                    onComplete(true)
                } else {
                    _uiState.update {
                        it.copy(isJoiningRoom = false, toastMessage = "Failed to join room. Check connection.")
                    }
                    onComplete(false)
                }
            } else {
                _uiState.update {
                    it.copy(isJoiningRoom = false, toastMessage = "Game code '$upperCode' not found.")
                }
                onComplete(false)
            }
        }
    }

    private fun processIncomingRoomState(roomModel: RoomNetworkModel) {
        val playerList = roomModel.players.values.toList()
        val myId = _uiState.value.myPlayer.id
        val updatedMe = roomModel.players[myId] ?: _uiState.value.myPlayer

        _uiState.update {
            it.copy(
                session = roomModel.session,
                players = playerList,
                myPlayer = updatedMe
            )
        }

        recalculateDistancesAndProximity()

        // Handle catch attempts (Organizer authoritative referee)
        if (_uiState.value.isOrganizer && roomModel.lastCatchAttempt != null) {
            val attempt = roomModel.lastCatchAttempt
            if (attempt.timestamp > lastHandledCatchAttemptTimestamp) {
                lastHandledCatchAttemptTimestamp = attempt.timestamp
                processCatchAttempt(attempt)
            }
        }
    }

    /**
     * Organizer toggles player role in Cloud Realtime Database
     */
    fun togglePlayerRole(playerId: String) {
        if (!_uiState.value.isOrganizer) return
        val current = _uiState.value.players.find { it.id == playerId } ?: return
        val nextRole = if (current.role == Role.SEEKER) Role.HIDER else Role.SEEKER
        val catchCode = if (nextRole == Role.HIDER) RandomCode.generateNumericCode(4) else ""
        val updatedPlayer = current.copy(role = nextRole, catchCode = catchCode)

        viewModelScope.launch {
            val joinCode = _uiState.value.session?.joinCode ?: return@launch
            firebaseSync.joinPlayer(joinCode, updatedPlayer)
        }
    }

    /**
     * Organizer auto balances roles
     */
    fun autoAssignRoles(ratio: Int = 3) {
        if (!_uiState.value.isOrganizer) return
        val players = _uiState.value.players
        if (players.isEmpty()) return
        val hiderCount = maxOf(1, players.size / (ratio + 1))
        val shuffled = players.shuffled()
        val joinCode = _uiState.value.session?.joinCode ?: return

        viewModelScope.launch {
            shuffled.forEachIndexed { index, p ->
                val isHider = index < hiderCount
                val updated = p.copy(
                    role = if (isHider) Role.HIDER else Role.SEEKER,
                    catchCode = if (isHider) RandomCode.generateNumericCode(4) else ""
                )
                firebaseSync.joinPlayer(joinCode, updated)
            }
        }
    }

    /**
     * Start match
     */
    fun startGame() {
        if (!_uiState.value.isOrganizer) return
        val s = _uiState.value.session ?: return

        viewModelScope.launch {
            firebaseSync.updateSession(
                s.joinCode,
                mapOf(
                    "status" to GameStatus.RUNNING.name,
                    "remainingSeconds" to (s.durationMinutes * 60)
                )
            )
        }
        startMasterCountdown()
    }

    /**
     * Safety pause toggle
     */
    fun toggleSafetyPause() {
        if (!_uiState.value.isOrganizer) return
        val s = _uiState.value.session ?: return
        val nextPaused = !s.isPaused

        viewModelScope.launch {
            firebaseSync.updateSession(
                s.joinCode,
                mapOf(
                    "isPaused" to nextPaused,
                    "status" to (if (nextPaused) GameStatus.PAUSED.name else GameStatus.RUNNING.name)
                )
            )
        }
    }

    private fun startMasterCountdown() {
        countdownTimerJob?.cancel()
        countdownTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val s = _uiState.value.session ?: break
                if (s.status == GameStatus.RUNNING && !s.isPaused && _uiState.value.isOrganizer) {
                    val remaining = s.remainingSeconds - 1
                    if (remaining <= 0) {
                        endGame(winner = Role.HIDER) // Hiders survived!
                        break
                    } else {
                        // Push timer tick to cloud every 5 seconds to reduce write quotas
                        if (remaining % 5 == 0) {
                            firebaseSync.updateSession(s.joinCode, mapOf("remainingSeconds" to remaining))
                        }
                    }
                }
            }
        }
    }

    fun toggleDarkMode() {
        _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
    }

    fun refreshBatteryOptimizationStatus() {
        val app = getApplication<Application>()
        val isExempt = BatteryOptimizationHelper.isBatteryOptimizationDisabled(app)
        _uiState.update { it.copy(isBatteryOptimizationExempt = isExempt) }
    }

    private fun handleMyLocationUpdate(lat: Double, lng: Double) {
        val s = _uiState.value.session
        val geofenceEval = if (s != null && s.zoneRadiusMeters > 0 && s.zoneCenterLat != 0.0) {
            GeofenceManager.evaluate(lat, lng, s.zoneCenterLat, s.zoneCenterLng, s.zoneRadiusMeters)
        } else {
            com.manhunt.app.util.GeofenceEvaluation(
                status = GeofenceStatus.INSIDE,
                distanceFromCenterMeters = 0.0,
                distanceToBoundaryMeters = 0.0,
                isOutside = false
            )
        }

        val updatedMe = _uiState.value.myPlayer.copy(
            latitude = lat,
            longitude = lng,
            isOutOfZone = geofenceEval.isOutside,
            lastUpdatedEpochMs = System.currentTimeMillis()
        )

        _uiState.update {
            it.copy(
                myPlayer = updatedMe,
                isOutOfZone = geofenceEval.isOutside,
                geofenceStatus = geofenceEval.status,
                geofenceMessage = geofenceEval.warningMessage
            )
        }

        // Push to Firebase REST
        if (s != null && s.joinCode.isNotEmpty()) {
            viewModelScope.launch {
                firebaseSync.updateLocation(s.joinCode, updatedMe.id, lat, lng, geofenceEval.isOutside)
            }
        }

        recalculateDistancesAndProximity()
    }

    private fun recalculateDistancesAndProximity() {
        val me = _uiState.value.myPlayer
        val others = _uiState.value.players.filter { it.id != me.id }

        if (me.role == Role.HIDER) {
            val seekers = others.filter { it.role == Role.SEEKER }
            var minDist = Double.MAX_VALUE
            var bestBearing = 0f

            for (seeker in seekers) {
                if (seeker.latitude != 0.0 && seeker.longitude != 0.0) {
                    val dist = GeoUtils.distanceMeters(me.latitude, me.longitude, seeker.latitude, seeker.longitude)
                    if (dist < minDist) {
                        minDist = dist
                        bestBearing = GeoUtils.bearingDegrees(me.latitude, me.longitude, seeker.latitude, seeker.longitude)
                    }
                }
            }

            _uiState.update {
                it.copy(
                    nearestSeekerDistance = if (minDist == Double.MAX_VALUE) -1.0 else minDist,
                    nearestSeekerBearing = bestBearing
                )
            }
        } else {
            val uncaughtHiders = others.filter { it.role == Role.HIDER && !it.isCaught }
            val catchable = uncaughtHiders.firstOrNull { hider ->
                if (hider.latitude != 0.0 && hider.longitude != 0.0) {
                    GeoUtils.distanceMeters(me.latitude, me.longitude, hider.latitude, hider.longitude) <= Constants.CATCH_PROXIMITY_METERS
                } else false
            }

            _uiState.update { it.copy(nearbyCatchableHider = catchable) }
        }
    }

    /**
     * Submit catch attempt
     */
    fun attemptCatch(targetHiderId: String, enteredCode: String) {
        val s = _uiState.value.session ?: return
        val payload = CatchAttemptPayload(
            seekerId = _uiState.value.myPlayer.id,
            targetHiderId = targetHiderId,
            enteredCode = enteredCode.trim(),
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            firebaseSync.sendCatchAttempt(s.joinCode, payload)
        }
    }

    private fun processCatchAttempt(attempt: CatchAttemptPayload) {
        val target = _uiState.value.players.find { it.id == attempt.targetHiderId } ?: return
        val s = _uiState.value.session ?: return

        if (target.catchCode == attempt.enteredCode) {
            val updatedTarget = target.copy(isCaught = true)
            val newCatches = s.totalCatches + 1

            viewModelScope.launch {
                firebaseSync.joinPlayer(s.joinCode, updatedTarget)
                firebaseSync.updateSession(s.joinCode, mapOf("totalCatches" to newCatches))

                // Check win condition
                val remainingHiders = _uiState.value.players
                    .filter { it.id != target.id && it.role == Role.HIDER && !it.isCaught }
                if (remainingHiders.isEmpty()) {
                    endGame(winner = Role.SEEKER)
                }
            }

            _uiState.update { it.copy(toastMessage = "${target.name} was tagged!") }
        } else {
            _uiState.update { it.copy(toastMessage = "Incorrect catch PIN.") }
        }
    }

    private fun endGame(winner: Role) {
        val s = _uiState.value.session ?: return
        viewModelScope.launch {
            firebaseSync.updateSession(
                s.joinCode,
                mapOf(
                    "status" to GameStatus.FINISHED.name,
                    "winnerRole" to winner.name
                )
            )

            // Persist to local Room database
            val me = _uiState.value.myPlayer
            db.matchHistoryDao().insertMatch(
                MatchHistoryEntity(
                    joinCode = s.joinCode,
                    rolePlayed = me.role.name,
                    isWin = me.role == winner,
                    durationSeconds = (s.durationMinutes * 60) - s.remainingSeconds,
                    catchesCount = s.totalCatches
                )
            )
        }
    }

    fun dismissToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun leaveGame() {
        val s = _uiState.value.session
        val me = _uiState.value.myPlayer
        if (s != null) {
            viewModelScope.launch {
                firebaseSync.leaveRoom(s.joinCode, me.id)
            }
        }
        countdownTimerJob?.cancel()
        _uiState.update {
            it.copy(
                session = null,
                players = emptyList(),
                isOrganizer = false
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        compass.stopListening()
        firebaseSync.stopSync()
    }
}

object RandomCode {
    private val CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    fun generateCode(length: Int): String {
        return (1..length).map { CHARS.random() }.joinToString("")
    }

    fun generateNumericCode(length: Int): String {
        return (1..length).map { (0..9).random() }.joinToString("")
    }
}
