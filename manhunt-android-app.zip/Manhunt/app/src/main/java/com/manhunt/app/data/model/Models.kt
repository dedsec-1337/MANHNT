package com.manhunt.app.data.model

enum class Role {
    SEEKER,
    HIDER
}

enum class GameStatus {
    LOBBY,
    RUNNING,
    PAUSED,
    FINISHED
}

enum class NetworkSyncStatus {
    ONLINE,    // Successfully syncing with Firebase REST over cellular data
    SYNCING,   // Request in flight
    OFFLINE    // Network error or offline
}

data class Player(
    val id: String = "",
    val name: String = "",
    val avatarEmoji: String = "🏃",
    val role: Role = Role.SEEKER,
    val isCaught: Boolean = false,
    val catchCode: String = "", // 4-digit PIN shown on Hider screen
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val isOutOfZone: Boolean = false,
    val lastUpdatedEpochMs: Long = System.currentTimeMillis()
)

data class GameSession(
    val roomId: String = "",
    val roomName: String = "",
    val joinCode: String = "",
    val hostPlayerId: String = "",
    val status: GameStatus = GameStatus.LOBBY,
    val zoneCenterLat: Double = 0.0,
    val zoneCenterLng: Double = 0.0,
    val zoneRadiusMeters: Double = 500.0,
    val durationMinutes: Int = 30,
    val remainingSeconds: Int = 1800,
    val isPaused: Boolean = false,
    val winnerRole: Role? = null,
    val totalCatches: Int = 0
)

/**
 * Root JSON structure stored under /rooms/{joinCode}.json in Firebase Realtime Database
 */
data class RoomNetworkModel(
    val session: GameSession = GameSession(),
    val players: Map<String, Player> = emptyMap(),
    val lastCatchAttempt: CatchAttemptPayload? = null
)

data class CatchAttemptPayload(
    val seekerId: String = "",
    val targetHiderId: String = "",
    val enteredCode: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
